package com.example.ojtbadaassignment14.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.ojtbadaassignment14.fragments.AboutFragment;
import com.example.ojtbadaassignment14.fragments.FavoriteListFragment;
import com.example.ojtbadaassignment14.fragments.MovieListFragment;
import com.example.ojtbadaassignment14.fragments.SettingFragment;

public class ViewPagerAdapter extends FragmentStateAdapter {

        private final MovieListFragment movieListFragment;
        private final FavoriteListFragment favoriteListFragment;
        private final SettingFragment settingFragment;
        private final AboutFragment aboutFragment;

        public ViewPagerAdapter(@NonNull FragmentActivity fragmentActivity, MovieListFragment movieListFragment,
                                FavoriteListFragment favoriteListFragment, SettingFragment settingFragment, AboutFragment aboutFragment) {
            super(fragmentActivity);
            this.movieListFragment = movieListFragment;
            this.favoriteListFragment = favoriteListFragment;
            this.settingFragment = settingFragment;
            this.aboutFragment = aboutFragment;
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            if(position == 0) {
                return movieListFragment;
            }else if(position == 1) {
                return favoriteListFragment;
            } else if(position == 2) {
                return settingFragment;
            } else {
                return aboutFragment;
            }
        }

        @Override
        public int getItemCount() {
            return 4;
        }
}
