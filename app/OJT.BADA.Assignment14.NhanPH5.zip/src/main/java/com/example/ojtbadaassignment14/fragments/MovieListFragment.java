package com.example.ojtbadaassignment14.fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.ojtbadaassignment14.MainActivity;
import com.example.ojtbadaassignment14.R;
import com.example.ojtbadaassignment14.adapters.MovieListAdapter;
import com.example.ojtbadaassignment14.api.MovieApiService;
import com.example.ojtbadaassignment14.api.RetrofitClient;
import com.example.ojtbadaassignment14.models.Movie;
import com.example.ojtbadaassignment14.models.Page;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MovieListFragment extends Fragment {

    private RecyclerView recyclerView;
    private MovieListAdapter movieListAdapter;

    private ProgressBar progressBar;

    private Page page;
    private List<Movie> movieList;
    private int currentPage = 1;
    private boolean isLoading = false; // to check if data is loading

    public static MovieListFragment newInstance() {
        MovieListFragment fragment = new MovieListFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    public MovieListFragment() {
        movieList = new ArrayList<>(); // init movie list
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("check", "onCreate: ");

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d("check", "onCreateView: ");
        View view = inflater.inflate(R.layout.fragment_movie_list, container, false);
        progressBar = view.findViewById(R.id.idPBLoading);
        recyclerView = view.findViewById(R.id.recycler_view);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        movieListAdapter = new MovieListAdapter(movieList);
        recyclerView.setAdapter(movieListAdapter);

        // get movie list
        getMovieList(currentPage);

        // set listener for RecyclerView
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (!isLoading && isNearEndOfList()) {
                    Log.d("checked", "onScrolled: load more data");
                    // set loading status to check point is loading more data and avoid loading more data at the same time
                    isLoading = true;
                    // load more data
                    getMovieList(++currentPage);
                }
            }

        });

        return view;
    }

    private boolean isNearEndOfList() {
        RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
        if (layoutManager instanceof LinearLayoutManager) {
            LinearLayoutManager linearLayoutManager = (LinearLayoutManager) layoutManager;
            int totalItemCount = linearLayoutManager.getItemCount();
            int lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
            Log.d("checked", "isNearEndOfList: " + totalItemCount + " " + lastVisibleItem);
            return totalItemCount <= (lastVisibleItem + 2);
        } else if (layoutManager instanceof GridLayoutManager) {
            GridLayoutManager gridLayoutManager = (GridLayoutManager) layoutManager;
            int totalItemCount = gridLayoutManager.getItemCount();
            int lastVisibleItem = gridLayoutManager.findLastVisibleItemPosition();
            Log.d("checked", "isNearEndOfList: " + totalItemCount + " " + lastVisibleItem);
            return totalItemCount <= (lastVisibleItem + 2);
        }
        return false;
    }

    /**
     * Get movies from API
     */
    private void getMovieList(int currentPage) {
        // Hiển thị progress bar trong khi chờ tải dữ liệu
        progressBar.setVisibility(View.VISIBLE);

        // get movie list
        RetrofitClient retrofitClient = RetrofitClient.getInstance();
        MovieApiService movieApiService = retrofitClient.getMovieApiService();

        Call<Page> call = movieApiService.getPopularMovies(RetrofitClient.API_KEY,  currentPage);
        call.enqueue(new Callback<Page>() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onResponse(@NonNull Call<Page> call, @NonNull Response<Page> response) {
                if (response.isSuccessful() && response.body() != null) {
                    // get page
                    page = response.body();

                    // get movie list
                    if(page != null) {
                        movieList.addAll(page.getResults());
                        movieListAdapter.notifyDataSetChanged();
                        progressBar.setVisibility(View.GONE);

                        // set loading status to false after loading data for next time loading
                        isLoading = false;

                        Log.d("check", "onResponse: " + movieList.size());
                        Log.d("check", "onResponse: " + movieList.get(0).getTitle());

                    } else {
                        showError();
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<Page> call, @NonNull Throwable t) {
                showError();
            }
        });
    }

    private void showError() {
        progressBar.setVisibility(View.GONE);
        Toast.makeText(getContext(), "Failed to load data", Toast.LENGTH_SHORT).show();
    }

    public void changeLayout(boolean isGridLayout) {
        if (isGridLayout) {
            recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        } else {
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        }
        movieListAdapter.setGridLayout(isGridLayout);
        recyclerView.setAdapter(movieListAdapter);
    }
}