package com.example.ojtbadaassignment14;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager2.widget.ViewPager2;

import com.example.ojtbadaassignment14.adapters.ViewPagerAdapter;
import com.example.ojtbadaassignment14.api.MovieApiService;
import com.example.ojtbadaassignment14.api.RetrofitClient;
import com.example.ojtbadaassignment14.fragments.AboutFragment;
import com.example.ojtbadaassignment14.fragments.FavoriteListFragment;
import com.example.ojtbadaassignment14.fragments.MovieListFragment;
import com.example.ojtbadaassignment14.fragments.SettingFragment;
import com.example.ojtbadaassignment14.models.Movie;
import com.example.ojtbadaassignment14.models.Page;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {


    private ArrayList<String> tabNameList;
    private ArrayList<Integer> tabIconList;

    // toolbar, drawer layout, navigation view,...
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    ActionBarDrawerToggle actionBarDrawerToggle;
    ImageButton btnChangeLayout;
    boolean isGridLayout = false;


    // view pager, tab layout
    private ViewPager2 viewPager2;
    private TabLayout tabLayout;

    // Fragments
    MovieListFragment movieListFragment;
    FavoriteListFragment favoriteListFragment;
    SettingFragment settingFragment;
    AboutFragment aboutFragment;


    private void init() {
        toolbar = findViewById(R.id.toolbar);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        viewPager2 = findViewById(R.id.view_pager);
        tabLayout = findViewById(R.id.tab_layout);
        btnChangeLayout = findViewById(R.id.change_layout_button);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // init view
        init();

        // set up toolbar
        setUpToolbar();
        // set toolbar click listener
        setNavigationItemSelectedListener();
        // set change layout button click listener
        btnChangeLayout.setOnClickListener(v -> {
            isGridLayout = !isGridLayout;
            if(isGridLayout) {
                btnChangeLayout.setImageResource(R.drawable.ic_list);
                movieListFragment.changeLayout(isGridLayout);
            } else {
                btnChangeLayout.setImageResource(R.drawable.ic_grid);
                movieListFragment.changeLayout(isGridLayout);
            }
        });

        // create fragments
        createFragments();

    }

    // create fragments for tab layout
    private void createFragments() {
        // create fragments
        movieListFragment = MovieListFragment.newInstance();
        favoriteListFragment = new FavoriteListFragment();
        settingFragment = new SettingFragment();
        aboutFragment = new AboutFragment();

        // create view pager adapter
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(this, movieListFragment,
                favoriteListFragment, settingFragment, aboutFragment);

        // set view pager adapter
        viewPager2.setAdapter(viewPagerAdapter);

        // set tab layout with view pager
        createTabName();
        createTabIcon();
        new TabLayoutMediator(tabLayout, viewPager2,
                (tab, position) -> {
                    tab.setText(tabNameList.get(position));
                    tab.setIcon(tabIconList.get(position));
                }
        ).attach();
    }


    private void createTabName() {
        tabNameList = new ArrayList<>();
        tabNameList.add("Movie List");
        tabNameList.add("Favorite List");
        tabNameList.add("Setting");
        tabNameList.add("About");
    }

    private void createTabIcon() {
        tabIconList = new ArrayList<>();
        tabIconList.add(R.drawable.ic_home);
        tabIconList.add(R.drawable.ic_favorite);
        tabIconList.add(R.drawable.ic_setting);
        tabIconList.add(R.drawable.ic_about);
    }



    // set up toolbar and navigation view
    private void setUpToolbar() {
        // Thiết lập Toolbar làm ActionBar để không nhận toolbar mặc định và gắn option menu vào toolbar
        setSupportActionBar(toolbar);
        // set up drawer layout
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_drawer, R.string.close_drawer);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
    }

    // set listener for navigation view in toolbar
    private void setNavigationItemSelectedListener() {
        navigationView.setNavigationItemSelectedListener(menuItem -> {
            int itemId = menuItem.getItemId();
            if(itemId == R.id.nav_movie_list) {
                viewPager2.setCurrentItem(0);
            } else if (itemId == R.id.nav_favorite_list) {
                viewPager2.setCurrentItem(1);
            } else if (itemId == R.id.nav_setting) {
                viewPager2.setCurrentItem(2);
            } else if (itemId == R.id.nav_about) {
                viewPager2.setCurrentItem(3);
            }
            drawerLayout.closeDrawers();
            return true;
        });
    }

    // set up option menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    // set up option menu click listener
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        if(itemId == R.id.menu_movie_list) {
            viewPager2.setCurrentItem(0);
        } else if (itemId == R.id.menu_favorie_list) {
            viewPager2.setCurrentItem(1);
        } else if (itemId == R.id.menu_setting) {
            viewPager2.setCurrentItem(2);
        } else if (itemId == R.id.menu_about) {
            viewPager2.setCurrentItem(3);
        }
        return super.onOptionsItemSelected(item);
    }



}