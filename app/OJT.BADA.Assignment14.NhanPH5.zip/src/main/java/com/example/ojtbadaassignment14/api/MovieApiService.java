package com.example.ojtbadaassignment14.api;

import com.example.ojtbadaassignment14.models.Page;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface MovieApiService {
    // https://api.themoviedb.org/3/movie/popular?api_key=e7631ffcb8e766993e5ec0c1f4245f93&pag

    @GET("movie/popular")
    Call<Page> getPopularMovies(@Query("api_key") String apiKey, @Query("page") int page);
}
